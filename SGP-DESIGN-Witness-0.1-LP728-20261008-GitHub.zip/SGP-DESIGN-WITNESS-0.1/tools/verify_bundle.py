"""Offline integrity/schema check. Does not authenticate R3 or prove source truth."""
import json,hashlib,sys
from pathlib import Path
import jsonschema
root=Path(__file__).resolve().parents[1]
entry=json.loads((root/'entry.json').read_text())
errors=[]
for r in entry['records']:
 p=(root/r['path']).resolve()
 if not p.is_relative_to(root):errors.append('OUT_OF_SCOPE: '+r['path']);continue
 if hashlib.sha256(p.read_bytes()).hexdigest()!=r['sha256']:errors.append('HASH_MISMATCH: '+r['id'])
 json.loads(p.read_text())
schema=json.loads((root/entry['receipt_schema']).read_text())
jsonschema.Draft202012Validator.check_schema(schema)
for p in (root/'receipts').glob('*.json'):
 try:jsonschema.validate(json.loads(p.read_text()),schema)
 except jsonschema.ValidationError as e:errors.append(str(p.name)+': '+e.message)
if errors:
 print('\n'.join(errors));sys.exit(1)
print('PASS: referenced JSON hashes and receipt schema. No truth or qualification certification implied.')
